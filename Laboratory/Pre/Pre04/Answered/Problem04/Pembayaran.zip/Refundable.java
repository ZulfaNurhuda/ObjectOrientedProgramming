public interface Refundable {
    void refund(int amount);   
}
