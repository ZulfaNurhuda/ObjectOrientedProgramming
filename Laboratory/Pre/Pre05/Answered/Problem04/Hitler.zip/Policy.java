public enum Policy {
    LIBERAL, FASCIST
}