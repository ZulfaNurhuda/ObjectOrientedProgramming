public class Enclosure<"TODO: isi type yang membatasi T hanya untuk Animal dan turunannya"> {
    private T animal;
    private String enclosureId;
    
    // TODO: Buat constructor yang menerima enclosureId dan animal (tipe T)
    // Set kedua atribut dengan parameter yang diterima
    
    // TODO: Buat method getAnimal() yang mengembalikan T
    // Return nilai animal
    
    // TODO: Buat method setAnimal(T animal)
    // Set atribut animal dengan parameter yang diterima
    
    // TODO: Buat method showEnclosureInfo()
    // Tampilkan: "Kandang <enclosureId>: <animal.getInfo()>"
    // Tampilkan: "Suara: <animal.makeSound()>"
    
    // TODO: Buat getter untuk enclosureId
}