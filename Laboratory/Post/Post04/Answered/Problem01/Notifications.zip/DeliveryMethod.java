/**
 * Metode pengiriman notifikasi yang dapat dipilih oleh subscriber.
 */
public enum DeliveryMethod {
    APP,
    EMAIL,
    SMS;
}
